Ewebserver
<br>
a web server that i wrote in c using sockets
<br>
how to compile:<br>
go to the build folder and type ../configure
after that type make
the executable should be placed in the source folder with the name "ewebserver
